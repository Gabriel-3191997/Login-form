const express = require('express')
const app = express()
const port = 3000
const serveStatic = require('serve-static')
const path = require('path')

app.use(serveStatic('static/ftp', {index: ['login.html']}));

app.get('/login',(req, res) => {

    res.sendFile((path.join(__dirname, 'static','ftp', 'login.html')));

});

app.post('/Dash_Board', (req, res) => {

    res.sendFile(path.join(__dirname, 'static', 'ftp', 'dashboard.html'));
});

app.listen(3000)