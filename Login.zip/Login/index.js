const express = require("express");
const app = express();
const port = 3000;
const serveStatic = require("serve-static");
const path = require("path");
const bodyParser = require("body-parser");

// Store signup information globally (for simplicity)
let users = [];

app.use(bodyParser.urlencoded({ extended: true }));

// Serve Bootstrap from node_modules
app.use(
  "/bootstrap",
  express.static(path.join(__dirname, "node_modules/bootstrap/dist"))
);

// Serve static files (login.html, registration.html, dashboard.html)
app.use(serveStatic("static/ftp", { index: ["login.html"] }));

// Redirect root path to login page
app.get("/", (req, res) => {
  res.redirect("/login");
});

// Endpoint to serve login.html
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "static", "ftp", "login.html"));
});

// Endpoint to serve registration.html
app.get("/registration", (req, res) => {
  res.sendFile(path.join(__dirname, "static", "ftp", "registration.html"));
});

// POST endpoint for handling login
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  // Simulated check against stored signup information
  const user = users.find(
    (u) => u.username === username && u.password === password
  );

  if (user) {
    // Redirect to dashboard if login is successful
    res.redirect("/Dash_Board");
  } else {
    // Redirect back to login page if login fails
    res.redirect("/login");
  }
});

// Endpoint to serve dashboard.html
app.post("/Dash_Board", (req, res) => {
  res.sendFile(path.join(__dirname, "static", "ftp", "dashboard.html"));
});

// POST endpoint for handling registration form submission
app.post("/registration", (req, res) => {
  const { username, password } = req.body;

  // Assuming username is unique for simplicity
  users.push({ username, password });

  // Redirect to login page after successful registration
  res.redirect("/login");
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
